#!/bin/sh
composer self-update --no-interaction
composer install --no-interaction
