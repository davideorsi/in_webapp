<?php namespace Way\Generators\Filesystem;

class FileNotFound extends \Exception {}
